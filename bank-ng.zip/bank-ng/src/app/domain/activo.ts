export class Activo {
    constructor(
        public id:string,
        public nombre:string
    ){}
}
