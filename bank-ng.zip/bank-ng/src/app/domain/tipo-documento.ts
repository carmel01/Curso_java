export class TipoDocumento {

    constructor(
        public tdocId:number,
	    public activo:string,
	    public nombre:string
    ){}
}
