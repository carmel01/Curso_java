export class Cliente {

    constructor(
        public  clieId:number,
        public  activo:string,
        public  direccion:string,
        public  email:string,
        public  nombre:string,
        public  telefono:string,
        public  tdocId:number
    ){}

}
